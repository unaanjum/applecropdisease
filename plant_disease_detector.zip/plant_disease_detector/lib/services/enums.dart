enum MenuItemEnum { dashboard, search, statistics, profile, none, home }


