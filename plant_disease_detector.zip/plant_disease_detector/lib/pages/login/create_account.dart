import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:plant_disease_detector/pages/home/home_screen.dart';
import 'package:plant_disease_detector/pages/home/image_picker.dart';
import 'package:plant_disease_detector/pages/login/login_screen.dart';
import 'package:plant_disease_detector/utils/constants.dart';
import 'package:plant_disease_detector/utils/widgets/appbar.dart';
import 'package:plant_disease_detector/utils/widgets/common_widget.dart';

class CreateAccount extends StatefulWidget {
  const CreateAccount({super.key});

  @override
  State<CreateAccount> createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {
  
  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passController = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Color(0xFFFFF2EE),
   body: 
      SingleChildScrollView(
        child: Column(
          children: [
               AppBarWithSearch(
              hasBackArrow: true,
            ),
             
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
        children: [
          RichText(
              textAlign: TextAlign.center,
              text: TextSpan(
                text: 'Sign Up for Apple Disease Detection',
      
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
          ),
          SizedBox(height: 32),
             CustomTextField(
                controller: _nameController,
                labelText: 'Username',
                hintText: 'Enter your username', 
                isRequired: true,
              ),
             CustomTextField(
                controller: _emailController,
                labelText: 'Email',
                hintText: 'Enter your email', 
                isRequired: true,
              ),
             CustomTextField(
                controller: _passController,
                labelText: 'Password',
                isRequired: true,
                 suffixIcon: Align(
            widthFactor:1,
            heightFactor:1,
           child: GestureDetector(
            onTap: (){
            },
             child: ImageIcon(
                AssetImage("assets/icons/password.png"),
           ),
           ),
      
          ),
              ),
      
               SizedBox(height: 32),
      
              SizedBox(
                width: Get.width,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                  },
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.zero,
                    primary: Colors.green,
                  ),
                  child: GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>
                    LoginScreen()
                     ));
                    },
                    child: const Text('Sign Up',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                    )),
                ),
              ),
      
                 SizedBox(height: 32),
      
               GestureDetector(
               onTap: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context)=>
                    LoginScreen()
                     ));
               }, 
                 child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: "Do you have already account?",
                    style: const TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                        color: Colors.black),
                    children: [
                      TextSpan(
                        text: 'Login here',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor,                        
                        ),
                      )
                    ],
                  ),
                               ),
               ),
           
        ],
          ),
            ),

               space3C,
               space3C
          
          ],
        ),
      ),
   
    );
  }
}