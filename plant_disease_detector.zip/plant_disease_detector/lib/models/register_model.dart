class RegisterModel {
  RegisterModel({
    this.name,
    this.email,
    this.phone,
    this.countryId,
    this.password,
    this.referelCode,
    this.gender,
  });

  String? name;
  String? email;
  String? phone;
  String? countryId;
  String? password;
  String? referelCode;
  String? gender;
}
