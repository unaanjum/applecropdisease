package com.example.plant_disease_detector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
